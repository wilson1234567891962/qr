package com.example.android.basicpermissions.webview

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.gson.Gson
import java.io.File
import java.util.*


const val FILE_PROVIDER = "com.co.app.unica.file.fileprovider"
const val KEY_HASH_ACH= "9vyxHBWPNcCvN7I"
class BridgeJavaScript(private val context: AppCompatActivity, private val webView: WebView) {


    @JavascriptInterface
    fun backPage() {
        context.finish()
    }


    @JavascriptInterface
    fun checkPermissionWebView(item: String) : Boolean {
        return true
    }

    @JavascriptInterface
    fun requestPermissionLaunch(item: String)  {

    }

    @JavascriptInterface
    fun getObjectData(item: String): String  {
        return ""
    }




    @JavascriptInterface
    fun saveData(data: String,  state: String ): Boolean  {
        return true
    }

}
