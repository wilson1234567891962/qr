package com.example.android.basicpermissions.webview

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.android.basicpermissions.R

class WebViewActivity : AppCompatActivity() {

    // Instancia de WebView.
    private lateinit var webview: WebView

    private val permission = arrayOf(Manifest.permission.CAMERA
            //,Manifest.permission.RECORD_AUDIO,
            //Manifest.permission.MODIFY_AUDIO_SETTINGS
    )
    private val requestCode = 1


    /**
     * Evento llamado al momento de abrir por primera vez la WebView.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        establecerParametrosWebView()
    }



    /**
     * Evento llamado al momento en que abandonamos y regresamos a la WebView.
     */
    override fun onResume() {
        super.onResume()

        establecerParametrosWebView()
    }


    /**
     * Realiza las configuraciones necesarias para la apertura del código QR en la WebView,
     * y sus permisos respectivos.
     */
    private fun establecerParametrosWebView() {
        setContentView(R.layout.activity_web_view)
        webview = findViewById(R.id.webview)

        val action: String? = intent?.action
        val data: Uri? = intent?.data


        WebViewSetup()
        if (!isPermissionGranted()) {

            askPermissions()

        }

        webview.webChromeClient = ActivityWebViewChrome(this)
    }


    private fun askPermissions() {
        ActivityCompat.requestPermissions(this, permission, requestCode)
    }

    private fun isPermissionGranted(): Boolean {
        permission.forEach {
            if (ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED)
                return false
        }

        return true
    }


    @SuppressLint("SetJavaScriptEnabled")
    private fun WebViewSetup() {

        val url = intent.extras!!.getString("url")
        val activity = this

        webview.apply {
            if (url != null) {
                loadUrl(url)
            }

            Log.d("callBtn", "Url ::  $url!!!! ")
            /** Habilitar ejecuci&oacute;n de c&oacute;digo JavaScript. */
            webview.webViewClient = ActivityWebView(activity)
            webview.webChromeClient = ActivityWebViewChrome(activity)
            settings.javaScriptEnabled = true
            /** Habilitar que JS abra ventanas autom&aacute;ticamente. */
            settings.javaScriptCanOpenWindowsAutomatically = true
            webview.addJavascriptInterface(BridgeJavaScript(activity, webview), "Android")
            /** Habilitar el API de DOM Storage. */
            settings.domStorageEnabled = true
            /** Permite el acceso a contenidos de la URL. */
            settings.allowContentAccess = true
            //settings.safeBrowsingEnabled = true
            /** Requiere del usuario para reproducir multimedia? */
            settings.mediaPlaybackRequiresUserGesture = false
        }
    }

}

class ActivityWebView(private val mainActivity: WebViewActivity) : WebViewClient() {

    @Deprecated("Version")
    override fun shouldOverrideUrlLoading(view: WebView, currentURL: String): Boolean {
        view.loadUrl(currentURL)
        return true
    }

    override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        val script = "function postMessageCallback(res, origin, originApp, op) {\n" +
                "      var parsedJson = JSON.parse(res);\n" +
                "      var response = {\n" +
                "        origin: \"super-app\" ,\n" +
                "        op: op,\n" +
                "        syncMode: true,\n" +
                "        code: parsedJson.code,\n" +
                "        message: parsedJson.message,\n" +
                "        data: parsedJson.data\n" +
                "      };\n" +
                "      if (response.data.document !== undefined && response.data.document.type === '1') {\n" +
                "          response.data.document.type = '02'\n" +
                "      } else if (response.data.document !== undefined && response.data.document.type !== '1') {\n" +
                "          response.data.document.type = ''\n" +
                "      }\n" +
                "      return window.postMessage(JSON.stringify(response), origin);\n" +
                "    }\n" +
                "    window.addEventListener(\"message\", function (event) {\n" +
                "      setTimeout(function() { return; }, 100);\n" +
                "      var eventData = \"\"\n" +
                "      try {\n" +
                "         eventData = JSON.parse(event.data);\n" +
                "      } catch {\n" +
                "         return;\n" +
                "      }\n" +
                "      if (eventData.code !== undefined) {\n" +
                "        return;\n" +
                "      }\n" +
                "      var payload = \"\";\n" +
                "      if (eventData.payload !== undefined) {\n" +
                "         if (eventData.payload.url) {\n" +
                "              payload = eventData.payload.url;\n" +
                "         } else if(eventData.payload.user) {\n" +
                "              payload = eventData.payload.user;\n" +
                "         } else if(eventData.payload.licenseKey) {\n" +
                "              payload = eventData.payload.licenseKey;\n" +
                "         }\n" +
                "      }\n" +
                "\n" +
                "\n" +
                "      var origin = \"app-unica\";\n" +
                "      var response = {\n" +
                "        origin: origin,\n" +
                "        op: eventData.op,\n" +
                "        syncMode: true,\n" +
                "        code: \"\",\n" +
                "        message: \"\",\n" +
                "        data: {}\n" +
                "      };\n" +
                "      var interfaceFunction = ''\n" +
                "      if (eventData.op !== undefined && eventData.op.includes('DSB') === false) {\n" +
                "        interfaceFunction = eventData.op;\n" +
                "      } else if (eventData.op !== undefined){\n" +
                "        interfaceFunction = eventData.op.split('DSB')[1];\n" +
                "      }\n" +
                "      if (Android[interfaceFunction]) {\n" +
                "        return Android[interfaceFunction](payload, 'postMessageCallback', event.origin, eventData.origin, eventData.op);\n" +
                "      } else {\n" +
                "        response.syncMode = eventData.syncMode;\n" +
                "        response.data = {};\n" +
                "        response.code = \"404\";\n" +
                "        response.message = \"Operation not found\";\n" +
                "        return event.source.postMessage(JSON.stringify(response), event.origin);\n" +
                "      }\n" +
                "      response.op = \"response\";\n" +
                "      response.syncMode = eventData.syncMode;\n" +
                "      response.data = {};\n" +
                "      response.code = \"403\";\n" +
                "      response.message = \"Origin not authorized\";\n" +
                "      return event.source.postMessage(JSON.stringify(response), event.origin);\n" +
                "    }, true)"

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            view.evaluateJavascript(script, null)
        } else {
            view.loadUrl("javascript:$script")
        }
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        handler!!.proceed()
    }
}

class ActivityWebViewChrome(context: Context) : WebChromeClient() {

    val context: Context = context

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onPermissionRequest(request: PermissionRequest) {
        request.grant(request.resources)
    }

    override fun onProgressChanged(view: WebView, progress: Int) {
    }

    override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
        callback!!.invoke(origin, true, true)
    }

}
